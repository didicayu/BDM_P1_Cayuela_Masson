# CyberSecIntel P2.2 Follow-Up Delivery

Main report: `CyberSecIntel_P2_2_Cayuela_Masson.pdf`

Contents:
- P2.2 report source, built PDF, and architecture asset under `docs/p2_2_delivery/`
- P2.1 design context under `docs/p2_1_delivery/`
- Trusted, Exploitation, and Consumption implementation packages
- Airflow DAGs and Docker Compose configuration
- Unit tests and generated consumption outputs

Local runtime artifacts intentionally excluded:
- `.env`, `.venv`, `.git`, `temporary/`, `data/`, Airflow logs, caches, and old P1 zip artifacts
